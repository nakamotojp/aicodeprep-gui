To install on MacOS (Apple M1/2/etc ARM64 hardware):

Copy the AICodePrepGUI.app to your Applications folder.

Then just double click the AICodePrepGUI.workflow to install the right click context menu to Finder
    (it will appear in the Quick Actions submenu)

- It may ask for annoying permissions the first time you run it, I am new to having a Mac
  so i don't fully understand this setup yet. Let me know if there are any problems.
